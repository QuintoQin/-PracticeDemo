//package com.example.dagger.demo1.base;
//
//import com.example.dagger.Cloth;
//import com.example.dagger.Clothes;
//
///**
// * Description： PracticeDemo
// * Copyright (c)
// * This program is protected by copyright laws.
// * package: com.example.dagger.demo1.base
// * Date: 2017/5/11
// * user: user QuintoQin
// *
// * @author 覃勤
// * @version : 1.0
// */
//public class ClothHandler {
//    public Clothes handle(Cloth cloth) {
//        return new Clothes(cloth);
//    }
//}

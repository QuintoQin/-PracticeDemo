//package com.example.dagger.demo1.base;
//
//import javax.inject.Singleton;
//
//import dagger.Module;
//import dagger.Provides;
//
///**
// * Description： PracticeDemo
// * Copyright (c)
// * This program is protected by copyright laws.
// * package: com.example.dagger.demo1.base
// * Date: 2017/5/11
// * user: user QuintoQin
// *
// * @author 覃勤
// * @version : 1.0
// */
//@Module
//public class BaseModule {
//
//    @Singleton
//    @Provides
//    public ClothHandler getClothHander(){
//        return new ClothHandler();
//    }
//}

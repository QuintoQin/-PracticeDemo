//package com.example.dagger.demo1.base.bean;
//
//import com.example.dagger.SimpleActivity;
//
//import dagger.Component;
//
///**
// * Description： PracticeDemo
// * Copyright (c)
// * This program is protected by copyright laws.
// * package: com.example.dagger.demo1.base.bean
// * Date: 2017/5/18
// * user: user QuintoQin
// *
// * @author 覃勤
// * @version : 1.0
// */
//@Component
//public interface SimpleComponent {
//    void Inject(SimpleActivity activity);
//}

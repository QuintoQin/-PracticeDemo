//package com.example.dagger;
//
//import javax.inject.Singleton;
//
//import dagger.Component;
//
///**
// * Description： PracticeDemo
// * Copyright (c)
// * This program is protected by copyright laws.
// * package: com.example.dagger
// * Date: 2017/5/11
// * user: user QuintoQin
// *
// * @author 覃勤
// * @version : 1.0
// */
//@Singleton
////@PerActivity
//@Component(modules = SecondModule.class)
//public interface SecondModule {
//    void inject(SecondActivity secondActivity);
//}

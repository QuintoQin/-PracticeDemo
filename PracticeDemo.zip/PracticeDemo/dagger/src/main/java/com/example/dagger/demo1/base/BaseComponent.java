//package com.example.dagger.demo1.base;
//
//import javax.inject.Singleton;
//
//import dagger.Component;
//
///**
// * Description： PracticeDemo
// * Copyright (c)
// * This program is protected by copyright laws.
// * package: com.example.dagger.demo1.base
// * Date: 2017/5/11
// * user: user QuintoQin
// *
// * @author 覃勤
// * @version : 1.0
// */
//@Singleton
//@Component(modules = BaseModule.class)
//public interface BaseComponent {
//    ClothHandler getClothHandler();
//}
